package bakery.repositories.interfaces;

public interface TableRepository<T> extends bakery.repositories.interfaces.Repository<T> {
    T getByNumber(int number);
}
